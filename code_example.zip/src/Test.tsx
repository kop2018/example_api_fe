import {
  createMeeClient,
  getMEEVersion,
  MEEVersion,
  toMultichainNexusAccount,
} from "@biconomy/abstractjs";
import {
  usePrivy,
  useSignAuthorization,
  useSign7702Authorization,
  useWallets,
} from "@privy-io/react-auth";
import {
  encodeFunctionData,
  http,
  parseUnits,
  type Abi,
  type Address,
} from "viem";
import { base, sei } from "viem/chains";
import { REWARD_DISTRIBUTION_ABI } from "./reward_distribution";
export const REWARD_DISTRIBUTION_ADDRESS =
  "0xe79f1C4b116E16429fFa1e1884A55083bE03466C";
export default function Test() {
  const { login } = usePrivy();
  const { wallets } = useWallets();
  const { signAuthorization } = useSignAuthorization();
  const handleTest = async () => {
    const wallet = wallets.find(
      (wallet) => wallet.walletClientType === "privy",
    );
    if (!wallet) {
      throw new Error("No wallet connected");
    }
    const authorization = await signAuthorization({
      contractAddress: getMEEVersion(MEEVersion.V2_1_0).implementationAddress,
      chainId: base.id,
      nonce: 0,
    });

    const proofs = [
      {
        epoch: 3,
        amount: 0.001,
        merkleProof: [
          "0xa86d54e9aab41ae5e520ff0062ff1b4cbd0b2192bb01080a058bb170d84e6457",
        ],
        token: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
      },
    ];

    const orchestrator = await toMultichainNexusAccount({
      chainConfigurations: [
        {
          chain: sei,
          transport: http(),
          version: getMEEVersion(MEEVersion.V2_1_0),
        },
        {
          chain: base,
          transport: http(),
          version: getMEEVersion(MEEVersion.V2_1_0),
        },
      ],
      signer: await wallet.getEthereumProvider(),
      accountAddress: wallet.address as Address,
    });

    const encodedCalls = proofs.map((proof) => {
      const decimals = 6;

      return encodeFunctionData({
        abi: REWARD_DISTRIBUTION_ABI,
        functionName: "claim",
        args: [
          BigInt(proof.epoch),
          parseUnits(proof.amount.toString(), decimals),
          proof.merkleProof as `0x${string}`[],
        ],
      });
    });

    const meeClient = await createMeeClient({
      account: orchestrator,
      apiKey: "mee_3ZfpUsSzpTi7MmqeE7vzrbYw",
    });

    const instruction = await orchestrator?.buildComposable({
      type: "default",
      data: {
        chainId: base.id,
        to: REWARD_DISTRIBUTION_ADDRESS as `0x${string}`,
        abi: REWARD_DISTRIBUTION_ABI as Abi,
        functionName: "multicall",
        args: [encodedCalls],
      },
    });

    console.log("Instruction:", instruction);
    const quote = await meeClient.getQuote({
      sponsorship: true,
      instructions: [instruction],
      authorizations: [authorization],
      delegate: true,
    });

    const { hash } = await meeClient.executeQuote({ quote });
    console.log("Transaction hash:", hash);
    const receipt = await meeClient.waitForSupertransactionReceipt({
      hash,
      confirmations: 2, // optional
    });
  };
  return (
    <div>
      Test
      <button onClick={() => login()}>Log wallets</button>
      <button onClick={handleTest}>Test</button>
    </div>
  );
}
