import "./App.css";
import Test from "./Test";

function App() {
  return (
    <>
      <div>
        <Test />
      </div>
    </>
  );
}

export default App;
